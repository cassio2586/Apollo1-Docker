You have to select the mts+mto route on the product form.
You should not select both the mts+mto route and the mto route.
